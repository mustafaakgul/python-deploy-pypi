from setuptools import setup

setup(name='iot_gaussian',
      version='0.1',
      description='Calculate and visuallize, Gaussian, Binomial and Normal distributions',
      packages=['iot_gaussian'],
      author_email='mustafaakguldev@icloud.com',
      zip_safe=False)